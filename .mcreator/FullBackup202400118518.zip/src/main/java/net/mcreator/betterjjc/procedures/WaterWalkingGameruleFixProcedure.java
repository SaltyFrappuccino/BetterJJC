package net.mcreator.betterjjc.procedures;

public class WaterWalkingGameruleFixProcedure {
	public static void execute() {
	}
}
